
# Corpora Samples

A tiny section of each corpus for testing its reader.
